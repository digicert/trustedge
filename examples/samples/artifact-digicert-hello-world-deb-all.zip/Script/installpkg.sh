#!/bin/bash
echo "Installing package ..."
sudo dpkg -i Package/digicert-hello-world-all.deb
if [ $? -eq 0 ]
then
   echo "Install was successful"
   exit 0
else
   echo "Install failed"
   exit 1
fi

#!/bin/bash
echo "Rollback package ..."
sudo dpkg -r digicert-hello-world-all
if [ $? -eq 0 ]
then
   echo "Rollback was successful"
   exit 0
else
   echo "Rollback failed"
   exit 1
fi
